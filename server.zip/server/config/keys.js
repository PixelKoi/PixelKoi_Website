module.exports = {
	SENDGRID_API: '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'
};
