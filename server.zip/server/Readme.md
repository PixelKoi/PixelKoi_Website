Run the TypeScript compiler by running the following command in your terminal:
```npx tsc```

This command will compile all .tsx files in the src directory and its subdirectories 
and output the resulting JavaScript files to the dist directory.
